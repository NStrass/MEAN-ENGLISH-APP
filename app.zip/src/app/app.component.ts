import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {

  public gameInProcess:boolean = true

  public finishGame(resultGame: string): void {
    console.log(resultGame);
    this.gameInProcess = false
   }

  //heroes: boolean = true;  //Setting the flag true to show the <ng-template>
 // LoggedIn: boolean = true;  //Setting the flag true to show the <ng-template>
    
}
