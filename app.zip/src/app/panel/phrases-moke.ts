import { Phrase } from "../shared/phrase.model";

export const PHRASES: Phrase[] = [
    { phraseEN: "I was wondering when we'll travel again", phrasePTBR: "Eu estava pensando quando vamos viajar denovo" },
    { phraseEN: "We expect big chances in the next vacations", phrasePTBR: "Nós esperamos grandes chances que nas próximas férias" },
    { phraseEN: "She seems very outgoing", phrasePTBR: "Ela parece muito extrovertida" },
    { phraseEN: "He is working on it", phrasePTBR: "Ele está melhorando" }
]