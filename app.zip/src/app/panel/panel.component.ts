import { Component, OnInit, EventEmitter, Output} from '@angular/core';

import { PHRASES } from "./phrases-moke";
import { Phrase } from "../shared/phrase.model";
//import { EventEmitter } from 'events';

@Component({
  selector: 'app-panel',
  templateUrl: './panel.component.html',
  styleUrls: ['./panel.component.css']
})
export class PanelComponent implements OnInit {

  public phraseList: Phrase[] = PHRASES
  public typedText = ""
  public turnNumber = 0
  public turnPhrase: Phrase
  public progress = 0
  public attemptsNumber = 3

  @Output() public finishGame: EventEmitter<string> = new EventEmitter()

  //@Output() public encerrar: EventEmitter<string> = new EventEmitter()

  constructor() {
    this.UpdateTurn()
  }

  ngOnInit() {
  }

  public updateText(typedText: Event): void {
    this.typedText = (<HTMLInputElement>typedText.target).value
  }

  public CheckText(): void {
    if (this.typedText != this.turnPhrase.phrasePTBR) {
      this.attemptsNumber--
      
      if (this.attemptsNumber == -1)
      this.finishGame.emit('Defeat')
      // else
      //   alert('Its wrong! Try again.')
    }
    else {
      this.progress += 100 / this.phraseList.length
      this.UpdateTurn()
      
      if (this.attemptsNumber == 4) {
        alert('Victory')
      }
      //alert('Its Correct! :D')
      
    }
  }

  public UpdateTurn() {
    this.turnPhrase = this.phraseList[this.turnNumber]
    this.turnNumber++
    this.typedText = ''
  }
}