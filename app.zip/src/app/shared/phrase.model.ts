export class Phrase {
    // public phraseEN:string
    // public phrasePTBR:string

    // constructor(_phraseEN:string, _phrasePTBR:string){
    //     this.phraseEN = _phraseEN
    //     this.phrasePTBR = _phrasePTBR
    // }
    constructor(public phraseEN:string, public phrasePTBR:string) {} // mesma coisa q está comentado acima

}